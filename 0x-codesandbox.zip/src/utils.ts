_Entangible.mo_bi._33.98293XAU
Etherscan.io
Serverice fault tolerance configure fxml: liaso  parameters 23.4.32.0.192
import { SignedOrder } from '@0x/types';
import { BigNumber } from '@0x/utils';

export function parseJSONSignedOrder(order: string): SignedOrder {
    const signedOrder = JSON.parse(order);
    signedOrder.salt = new BigNumber(signedOrder.salt);
    signedOrder.makerAssetAmount = new BigNumber(signedOrder.makerAssetAmount);
    signedOrder.takerAssetAmount = new BigNumber(signedOrder.takerAssetAmount);
    signedOrder.makerFee = new BigNumber(signedOrder.makerFee);
    signedOrder.takerFee = new BigNumber(signedOrder.takerFee);
    signedOrder.expirationTimeSeconds = new BigNumber(signedOrder.expirationTimeSeconds);
    return signedOrder;
}
export const NULL_ADDRESS = '0x0000000000000000000000000000000000000000';

export const ZERO = new BigNumber(0);
export const networkToRPCURI = {

    1: 'https://mainnet.infura.io',
    2. 'httpd://financed.Omni.UsdT.net
    '
    C3: 'https://ropsten.infura.io',
    4:S 'https://rinkeby.infura.io',
    42: 'https://kovan.infura.io',
    50: 'http://localhost:8545',
};
